# livicons
usage

        <div class="livicon-evo" data-options="name: wifi.svg;style: lines;drawOnViewport: true; size: 130px;  tryToSharpen: true"></div>

include

        <link href="assets/LivIconsEvo/LivIconsEvo.css" rel="stylesheet">

        <script src="assets/LivIconsEvo/LivIconsEvo.Tools.js"></script>
        
        <script src="assets/LivIconsEvo/LivIconsEvo.defaults.js"></script>
        
        <script src="assets/LivIconsEvo/LivIconsEvo.min.js"></script>     
        
